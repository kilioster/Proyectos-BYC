// Initialization for ES Users
import {
    Tab,
    initTWE,
  } from "tw-elements";
  
  initTWE({ Tab });